THREE.JS CHARACTER STORY - VERSION 2

For repository:
https://github.com/Mashrafiarif/3d-animation-engine

UPLOAD/REPLACE ONLY TWO FILES IN: threejs-demo/
  index.html
  sound.py

Do not change render.mjs, package.json, or the fixed workflow YAML.

On Safari/iPhone, open
https://github.com/Mashrafiarif/3d-animation-engine/tree/main/threejs-demo
Choose three dots -> Upload files; choose both files inside
01_UPLOAD_IN_THREEJS_DEMO; commit directly to main.

Then go to Actions -> Render Three.js Demo with Sound -> Run workflow:
Quality: portrait-preview
FPS: 24
Seconds: 8

This first test is 360x640, 192 frames, using original synchronized stereo SFX.
Once successful, use portrait-hd/30 and eventually portrait-full/60.

STORYBOARD (8 seconds):
0.00-1.85 Robot walks toward a glowing object (footsteps)
1.85-2.48 Robot notices and tilts head (curiosity ping)
2.48-3.48 Robot reaches (whoosh)
3.48-4.70 Robot picks up and lifts (click + ascending notes)
4.70-6.30 Crystal glows; robot reacts (sparkles + chord)
6.30-8.00 Robot turns and presents the crystal (whoosh + end chord)

Important: Three.js on free GitHub runners uses software WebGL;
complex high-resolution 60fps renders may take substantial time.
A generated artifact needs to be tested visually to confirm framing and polish.
